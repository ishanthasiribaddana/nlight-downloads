@echo off
title NLight IDE Setup v2.2.3
color 0A
echo.
echo  ╔══════════════════════════════════════════════════════════════╗
echo  ║                                                              ║
echo  ║                    NLight IDE Setup v2.2.3                 ║
echo  ║                  AI Programming Assistant                    ║
echo  ║                                                              ║
echo  ╚══════════════════════════════════════════════════════════════╝
echo.
echo  Welcome to NLight IDE v2.2.3 - Your AI-powered programming environment!
echo.
echo  This installer will set up everything you need in just a few minutes.
echo.
echo  What's new in v2.2.3:
echo    ✓ Improved AI setup process
echo    ✓ Enhanced error handling
echo    ✓ Better student experience
echo    ✓ Complete development environment
echo.
echo  What you'll get:
echo    ✓ Complete development environment
echo    ✓ Built-in AI programming assistant
echo    ✓ No technical setup required
echo    ✓ Works completely offline
echo.
pause
echo.
echo  Starting installation...
echo.

REM Check if running as administrator
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo  Note: Running as administrator is recommended for best results.
    echo.
)

REM Create installation directory
set INSTALL_DIR=%LOCALAPPDATA%\NLightIDE
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

cd /d "%INSTALL_DIR%"

echo  [1/4] Downloading NLight IDE components...

REM Download IDE installer (hidden from user)
echo  Downloading development environment...

REM Try multiple download methods
echo  Attempting download (Method 1: PowerShell)...
powershell -Command "$ProgressPreference='SilentlyContinue'; try { Invoke-WebRequest -Uri 'https://github.com/VSCodium/vscodium/releases/latest/download/VSCodium-win32-x64-user-setup.exe' -OutFile 'nlight-ide-setup.exe' -TimeoutSec 120 } catch { Write-Host 'Download failed' }"

if not exist "nlight-ide-setup.exe" (
    echo  Method 1 failed, trying Method 2: curl...
    curl -L -o "nlight-ide-setup.exe" "https://github.com/VSCodium/vscodium/releases/latest/download/VSCodium-win32-x64-user-setup.exe" --connect-timeout 120 --max-time 300
)

if not exist "nlight-ide-setup.exe" (
    echo.
    echo  ❌ ERROR: Failed to download development environment
    echo.
    echo  Possible solutions:
    echo  1. Check your internet connection
    echo  2. Temporarily disable antivirus/firewall
    echo  3. Run as administrator
    echo  4. Try downloading manually:
    echo     https://github.com/VSCodium/vscodium/releases/latest/download/VSCodium-win32-x64-user-setup.exe
    echo     Save as: nlight-ide-setup.exe in this folder: %CD%
    echo.
    echo  After downloading manually, press any key to continue...
    pause
    
    if not exist "nlight-ide-setup.exe" (
        echo  File not found. Please download manually first.
        pause
        exit /b 1
    )
)

echo  [2/4] Preparing NLight AI v2.2.3...

REM Copy NLight extension from bundle
copy "NLight.vsix" "nlight-ai.vsix" >nul

echo  [3/4] Copying interactive setup guide...

REM Copy interactive setup guide
copy "Student_Setup_Guide_Interactive.html" "Student_Setup_Guide_Interactive.html" >nul

echo  [4/4] Installing NLight IDE...

REM Install IDE silently (hidden from user)
echo  Installing development environment...
start /wait nlight-ide-setup.exe /S /MERGETASKS=!runcode /D=%LOCALAPPDATA%\NLightIDE\IDE

REM Find installation path
set IDE_PATH=%LOCALAPPDATA%\NLightIDE\IDE\bin
if not exist "%IDE_PATH%\codium.exe" (
    set IDE_PATH=%ProgramFiles%\NLightIDE\bin
    if not exist "%IDE_PATH%\codium.exe" (
        set IDE_PATH=%ProgramFiles(x86)%\NLightIDE\bin
    )
)

if not exist "%IDE_PATH%\codium.exe" (
    echo.
    echo  ❌ ERROR: IDE installation failed
    echo     Please try running this installer as administrator.
    echo.
    pause
    exit /b 1
)

echo  Installing NLight AI...

REM Install NLight extension
"%IDE_PATH%\codium.cmd" --install-extension "%INSTALL_DIR%\nlight-ai.vsix" --force

echo  Creating shortcuts...

REM Create desktop shortcut
powershell -Command "$WshShell = New-Object -comObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut('%USERPROFILE%\Desktop\NLight IDE.lnk'); $Shortcut.TargetPath = '%IDE_PATH%\codium.exe'; $Shortcut.IconLocation = '%INSTALL_DIR%\nlight-ai.vsix'; $Shortcut.Save()"

REM Create Start Menu shortcut
powershell -Command "$WshShell = New-Object -comObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut('%APPDATA%\Microsoft\Windows\Start Menu\Programs\NLight IDE.lnk'); $Shortcut.TargetPath = '%IDE_PATH%\codium.exe'; $Shortcut.IconLocation = '%INSTALL_DIR%\nlight-ai.vsix'; $Shortcut.Save()"

REM Create launcher script
echo @echo off > "%INSTALL_DIR%\NLight IDE.bat"
echo title NLight IDE v2.2.3 >> "%INSTALL_DIR%\NLight IDE.bat"
echo cd /d "%~dp0" >> "%INSTALL_DIR%\NLight IDE.bat"
echo start "" "%IDE_PATH%\codium.exe" --disable-telemetry --disable-update --disable-crash-reporter >> "%INSTALL_DIR%\NLight IDE.bat"

REM Create AI setup script
echo @echo off > "%INSTALL_DIR%\Setup NLight AI.bat"
echo title NLight AI Setup v2.2.3 >> "%INSTALL_DIR%\Setup NLight AI.bat"
echo echo Setting up NLight AI v2.2.3... >> "%INSTALL_DIR%\Setup NLight AI.bat"
echo echo This will download the AI model (one-time setup) >> "%INSTALL_DIR%\Setup NLight AI.bat"
echo echo. >> "%INSTALL_DIR%\Setup NLight AI.bat"
echo start "" "%IDE_PATH%\codium.exe" --disable-telemetry --disable-update --disable-crash-reporter --command "nlight.setupForStudent" >> "%INSTALL_DIR%\Setup NLight AI.bat"

REM Create setup guide shortcut
powershell -Command "$WshShell = New-Object -comObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut('%USERPROFILE%\Desktop\NLight Setup Guide.lnk'); $Shortcut.TargetPath = '%INSTALL_DIR%\Student_Setup_Guide_Interactive.html'; $Shortcut.Save()"

REM Cleanup
echo  Cleaning up...
del "nlight-ide-setup.exe"
del "nlight-ai.vsix"

echo.
echo  ╔══════════════════════════════════════════════════════════════╗
echo  ║                                                              ║
echo  ║              ✅ INSTALLATION COMPLETE!                      ║
echo  ║                                                              ║
echo  ╚══════════════════════════════════════════════════════════════╝
echo.
echo  🌟 NLight IDE v2.2.3 has been successfully installed!
echo.
echo  To start using NLight:
echo.
echo  1. Double-click "NLight IDE" on your desktop
echo     (or look in Start Menu)
echo.
echo  2. When NLight IDE opens, press Ctrl+Shift+P
echo.
echo  3. Type: "NLight: Setup AI (One-time)"
echo.
echo  4. Wait for AI setup to complete
echo.
echo  5. Look for "NLight" in the left sidebar
echo     Click "Chat" and start coding with AI!
echo.
echo  📚 Setup Guide:
echo    Double-click "NLight Setup Guide" on your desktop
echo    For interactive help and troubleshooting
echo.
echo  🎓 You're ready to start coding with AI assistance!
echo.
echo  🚀 Version 2.2.3 includes the latest improvements!
echo.
echo  Press any key to exit...
pause >nul
