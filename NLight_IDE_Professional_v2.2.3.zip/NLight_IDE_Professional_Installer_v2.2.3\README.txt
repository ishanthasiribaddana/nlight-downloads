# NLight IDE v2.2.3 - Professional Installation 
 
## 🚀 Quick Installation 
 
1. Double-click "Install NLight IDE.bat" 
2. Follow the installation wizard 
3. Launch "NLight IDE" from desktop 
4. Press Ctrl+Shift+P and type "NLight: Setup AI" 
5. Start coding with AI assistance! 
 
## 🎯 What You Get 
- Complete development environment 
- Built-in AI programming assistant 
- No technical setup required 
- Works completely offline 
- 100% private and free 
 
## 🆘 Need Help? 
- Open "Setup Guide.html" for interactive help 
- Contact your instructor for assistance 
