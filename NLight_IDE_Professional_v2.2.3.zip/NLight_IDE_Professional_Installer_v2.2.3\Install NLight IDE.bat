@echo off 
title NLight IDE v2.2.3 Setup 
color 0A 
echo. 
echo  ╔══════════════════════════════════════════════════════════════╗ 
echo  ║                                                              ║ 
echo  ║                NLight IDE v2.2.3 Setup                 ║ 
echo  ║                  AI Programming Assistant                    ║ 
echo  ║                                                              ║ 
echo  ╚══════════════════════════════════════════════════════════════╝ 
echo. 
echo  Welcome to NLight IDE v2.2.3! 
echo. 
echo  This will install your complete AI programming environment. 
echo. 
pause 
echo. 
echo  Starting installation... 
call setup.bat 
