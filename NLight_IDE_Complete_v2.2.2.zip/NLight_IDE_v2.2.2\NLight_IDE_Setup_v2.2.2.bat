@echo off
title NLight IDE Setup v2.2.2
color 0A
echo.
echo  +--------------------------------------------------------------+
echo  �                                                              �
echo  �                    NLight IDE Setup v2.2.2                 �
echo  �                  AI Programming Assistant                    �
echo  �                                                              �
echo  +--------------------------------------------------------------+
echo.
echo  Welcome to NLight IDE - Your AI-powered programming environment!
echo.
echo  This installer will set up everything you need in just a few minutes.
echo.
echo  What you'll get:
echo    ? Complete development environment
echo    ? Built-in AI programming assistant
echo    ? No technical setup required
echo    ? Works completely offline
echo.
pause
echo.
echo  Starting installation...
echo.

REM Check if running as administrator
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo  Note: Running as administrator is recommended for best results.
    echo.
)

REM Create installation directory
set INSTALL_DIR=%LOCALAPPDATA%\NLightIDE
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

cd /d "%INSTALL_DIR%"

echo  [1/4] Downloading NLight IDE components...

REM Copy VS Codium installer from bundle
copy "F:\CLI\NLight_IDE_v2.2.2\VSCodiumSetup.exe" "nlight-ide-setup.exe" >nul

echo  [2/4] Preparing NLight AI...

REM Copy NLight extension from bundle
copy "F:\CLI\NLight_IDE_v2.2.2\NLight.vsix" "nlight-ai.vsix" >nul

echo  [3/4] Installing NLight IDE...

REM Install VS Codium silently
start /wait nlight-ide-setup.exe /S /MERGETASKS=!runcode /D=%LOCALAPPDATA%\NLightIDE\VSCodium

REM Find installation path
set CODIUM_PATH=%LOCALAPPDATA%\NLightIDE\VSCodium\bin
if not exist "%CODIUM_PATH%\codium.exe" (
    set CODIUM_PATH=%ProgramFiles%\VSCodium\bin
    if not exist "%CODIUM_PATH%\codium.exe" (
        set CODIUM_PATH=%ProgramFiles(x86)%\VSCodium\bin
    )
)

if not exist "%CODIUM_PATH%\codium.exe" (
    echo.
    echo  ? ERROR: IDE installation failed
    echo     Please try running this installer as administrator.
    echo.
    pause
    exit /b 1
)

echo  [4/4] Installing NLight AI...

REM Install NLight extension
"%CODIUM_PATH%\codium.cmd" --install-extension "%INSTALL_DIR%\nlight-ai.vsix" --force

echo  Creating shortcuts...

REM Create desktop shortcut
powershell -Command "$WshShell = New-Object -comObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut('%USERPROFILE%\Desktop\NLight IDE.lnk'); $Shortcut.TargetPath = '%CODIUM_PATH%\codium.exe'; $Shortcut.IconLocation = '%INSTALL_DIR%\nlight-ai.vsix'; $Shortcut.Save()"

REM Create Start Menu shortcut
powershell -Command "$WshShell = New-Object -comObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut('%APPDATA%\Microsoft\Windows\Start Menu\Programs\NLight IDE.lnk'); $Shortcut.TargetPath = '%CODIUM_PATH%\codium.exe'; $Shortcut.IconLocation = '%INSTALL_DIR%\nlight-ai.vsix'; $Shortcut.Save()"

REM Create launcher script
echo @echo off > "%INSTALL_DIR%\NLight IDE.bat"
echo title NLight IDE >> "%INSTALL_DIR%\NLight IDE.bat"
echo cd /d "%~dp0" >> "%INSTALL_DIR%\NLight IDE.bat"
echo start "" "%CODIUM_PATH%\codium.exe" --disable-telemetry --disable-update --disable-crash-reporter >> "%INSTALL_DIR%\NLight IDE.bat"

REM Create AI setup script
echo @echo off > "%INSTALL_DIR%\Setup NLight AI.bat"
echo title NLight AI Setup >> "%INSTALL_DIR%\Setup NLight AI.bat"
echo echo Setting up NLight AI... >> "%INSTALL_DIR%\Setup NLight AI.bat"
echo echo This will download the AI model (one-time setup) >> "%INSTALL_DIR%\Setup NLight AI.bat"
echo echo. >> "%INSTALL_DIR%\Setup NLight AI.bat"
echo start "" "%CODIUM_PATH%\codium.exe" --disable-telemetry --disable-update --disable-crash-reporter --command "nlight.setupForStudent" >> "%INSTALL_DIR%\Setup NLight AI.bat"

REM Cleanup
echo  Cleaning up...
del "nlight-ide-setup.exe"
del "nlight-ai.vsix"

echo.
echo  +--------------------------------------------------------------+
echo  �                                                              �
echo  �              ? INSTALLATION COMPLETE!                      �
echo  �                                                              �
echo  +--------------------------------------------------------------+
echo.
echo  ?? NLight IDE v2.2.2 has been successfully installed!
echo.
echo  To start using NLight:
echo.
echo  1. Double-click "NLight IDE" on your desktop
echo     (or look in Start Menu)
echo.
echo  2. When NLight IDE opens, press Ctrl+Shift+P
echo.
echo  3. Type: "NLight: Setup AI (One-time)"
echo.
echo  4. Wait for AI setup to complete
echo.
echo  5. Look for "NLight" in the left sidebar
echo     Click "Chat" and start coding with AI!
echo.
echo  ?? You're ready to start coding with AI assistance!
echo.
echo  Press any key to exit...
pause >nul
